<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\SeriesMaster;
use App\Models\Bet;
use App\Models\Result;
use App\Models\UserBalanceTransaction;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class GenerateDrawResults extends Command
{
    protected $signature = 'draw:generate-results';
    protected $description = 'Automate 15-min draw results with profitability control';

    const DEFAULT_COMMISSION = 5;
    const TARGET_HOUSE_PROFIT_PERCENT = 40; // House aims to keep 40% of total bets
    const PAYOUT_MULTIPLIER = 90;           // Standard payout (e.g., 1 point = 90 points win)

    public function handle()
    {
        $now       = Carbon::now();
        $startTime = config('app.draw_start');
        $endTime   = config('app.draw_end');

        if ($now->format('H:i') < $startTime || $now->format('H:i') > $endTime) {
            $this->info("Outside draw hours ($startTime - $endTime). Skipping.");
            return;
        }

        $minutes      = $now->minute;
        $targetMinute = floor($minutes / 15) * 15;
        $drawTime     = $now->copy()->minute($targetMinute)->second(0);

        $this->info("Generating results for Draw Time: " . $drawTime->format('Y-m-d H:i:s'));

        $seriesList = SeriesMaster::all();

        if ($seriesList->isEmpty()) {
            $this->warn("No series found. Exiting.");
            return;
        }

        foreach ($seriesList as $mainSeries) {
            for ($i = 0; $i < 10; $i++) {
                $subSeriesStart = (int) $mainSeries->start + ($i * 100);

                $exists = Result::where('draw_time', $drawTime)
                    ->where('series', $subSeriesStart)
                    ->exists();

                if ($exists) {
                    $this->line("Result already exists for $subSeriesStart. Skipping.");
                    continue;
                }

                try {
                    $this->processSubSeriesResult($mainSeries, $subSeriesStart, $drawTime);
                } catch (\Throwable $e) {
                    $this->error("Error processing $subSeriesStart: " . $e->getMessage());
                    \Illuminate\Support\Facades\Log::error("DrawResult Error [$subSeriesStart]: " . $e->getMessage());
                }
            }
        }

        $this->info("Execution Completed!");
    }

    private function processSubSeriesResult($mainSeries, $subSeriesStart, $drawTime)
    {
        DB::transaction(function () use ($mainSeries, $subSeriesStart, $drawTime) {
            $subSeriesEnd = $subSeriesStart + 99;

            // 1. Get all bets for this range

            $bets = Bet::where('series_id', $mainSeries->id)
                ->where('draw_time', $drawTime)
                ->where('status', 'pending')
                ->where('number', '>=', $subSeriesStart)
                ->where('number', '<=', $subSeriesEnd)
                ->with('user')
                ->lockForUpdate()
                ->get();

            $totalPointsCollected = $bets->sum('points');

            // 2. Calculate Payout Scenarios for all 100 numbers
            $payoutScenarios = [];
            for ($n = 0; $n <= 99; $n++) {
                $fullNumber = $subSeriesStart + $n;
                $pointsOnNumber = $bets->where('number', (string) $fullNumber)->sum('points');

                // Potential house payout if this number wins
                $payoutScenarios[$fullNumber] = $pointsOnNumber * self::PAYOUT_MULTIPLIER;
            }

            // 3. Get Recent Results to avoid repetition (Last 5 draws)
            $recentNumbers = Result::where('series', $subSeriesStart)
                ->orderBy('draw_time', 'desc')
                ->take(5)
                ->pluck('result_number')
                ->toArray();

            // 4. Find "Safe" numbers (where house profit >= 40%)
            $safeNumbers = array_filter($payoutScenarios, function ($payout) use ($totalPointsCollected) {
                if ($totalPointsCollected == 0) return true; // All numbers safe if no bets
                $profit = $totalPointsCollected - ($payout / 100 * (100 - self::DEFAULT_COMMISSION));
                $profitMargin = ($profit / $totalPointsCollected) * 100;
                return $profitMargin >= self::TARGET_HOUSE_PROFIT_PERCENT;
            });

            // 5. Pick Winning Number (LOWEST PAYOUT STRATEGY)

            // Use ONLY safe numbers
            $filteredScenarios = collect($safeNumbers)

                // Avoid recent repeats
                ->reject(function ($payout, $number) use ($recentNumbers) {
                    return in_array($number, $recentNumbers);
                });

            // Fallback
            if ($filteredScenarios->isEmpty()) {
                $filteredScenarios = collect($safeNumbers);
            }

            // Emergency fallback
            if ($filteredScenarios->isEmpty()) {
                $filteredScenarios = collect($payoutScenarios);
            }

            // Lowest payout first
            $sorted = $filteredScenarios->sort();

            // Top lowest payout numbers
            $topLowNumbers = $sorted->take(15);

            // Random among low payout numbers
            $winningNumber = $topLowNumbers
                ->keys()
                ->random();

            // 6. Create Result record
            Result::create([
                'draw_time'     => $drawTime,
                'series'        => $subSeriesStart,
                'result_number' => $winningNumber,
            ]);

            // 7. Process bets
            foreach ($bets as $bet) {
                if ($bet->status !== 'pending') continue;

                if ((int) $bet->number === (int) $winningNumber) {
                    $user = $bet->user ?? User::find($bet->user_id);
                    if (!$user) {
                        $bet->update(['status' => 'lost']);
                        continue;
                    }

                    $rawCommission  = $user->commision;
                    $commissionRate = (!is_null($rawCommission) && $rawCommission > 0)
                        ? (float) $rawCommission
                        : self::DEFAULT_COMMISSION;

                    $netMultiplier = 100 - $commissionRate;
                    $winAmount     = $bet->points * $netMultiplier;

                    $bet->update(['status' => 'won']);
                    $user->increment('balance', $winAmount);

                    UserBalanceTransaction::create([
                        'user_id'       => $user->id,
                        'type'          => 'credit',
                        'amount'        => $winAmount,
                        'balance_after' => $user->fresh()->balance,
                        'remarks'       => "WIN: Draw " . $drawTime->format('h:i A') .
                            " | No: $winningNumber | Payout: {$winAmount}",
                    ]);
                } else {
                    $bet->update(['status' => 'lost']);
                }
            }

            $this->info("Processed $subSeriesStart: Result $winningNumber (Collected: $totalPointsCollected)");
        });
    }
}
